import os as _os
print(_os.environ.get("TERM", "unknown"))
